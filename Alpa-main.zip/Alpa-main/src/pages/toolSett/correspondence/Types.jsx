import React from 'react'
import corresIcon from '../../../assets/create_corres.png'

const Types = () => {
  return (
    <div className='px-12 min-h-[430px] flex justify-center items-center'>
        <img src={corresIcon} className='max-w-[480px] h-[350px]' alt="" />
    </div>
  )
}

export default Types