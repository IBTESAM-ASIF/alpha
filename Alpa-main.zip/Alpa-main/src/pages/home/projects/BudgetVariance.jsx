import React from 'react'

const BudgetVariance = () => {
  return (
    <div>BudgetVariance</div>
  )
}

export default BudgetVariance